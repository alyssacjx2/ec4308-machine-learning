EMA half-hourly system demand data, compiled into yearly files
==============================================================

Source: Energy Market Authority (EMA), "Half-hourly System Demand Data"
https://www.ema.gov.sg/resources/statistics/half-hourly-system-demand-data
Retrieved: 13 Oct 2026. Compiled with Claude (Anthropic) via Claude in Chrome.

Inputs: 562 weekly EMA spreadsheets (one per week, named by the Monday the week starts),
dated 28 Dec 2015 to 28 Sep 2026. Each covers Monday to Sunday.
Output: one CSV per calendar year, 1 Jan 2016 to 30 Sep 2026 (2026 file is Jan-Sep only).
Days outside that range (28-31 Dec 2015, 1-4 Oct 2026) were dropped.

Columns
-------
date                      Trading date (YYYY-MM-DD), Singapore time.
period                    Half-hour period of the day, 1-48.
period_ending             Period ending time as published by EMA. Period 48 ends at 00:00 (midnight).
datetime_end              Date and time the period ends; period 48 rolls over to the next day at 00:00.
system_demand_actual_mw   EMA note: includes demand of consumers with their own embedded generators.
nem_demand_actual_mw      EMA note: actual demand met by all Generation Registered Facilities.
nem_demand_forecast_mw    EMA note: forecast demand for scheduling of Generation Registered Facilities.
source_file               The EMA weekly file the row came from.
All demand values are in MW, exactly as published (no rounding or cleaning).

Checks run
----------
Rows: 188448 (3,926 days x 48 periods). No missing days, no missing periods, no blank values.
No week appeared in more than one file.
Note: in 398 half-hours (in 2016, 2018, 2019, 2021, 2023, 2024 and 2026), system demand is below NEM demand, by up to about 670 MW,
although by definition it should be at least as large.
These are left as published.
One listing on the EMA page (06 Oct 2020) has only a PDF; the 05 Oct 2020 spreadsheet covers that week.
